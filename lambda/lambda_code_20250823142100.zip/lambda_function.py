import psycopg2
import json
import re
from google.cloud import storage
from google.cloud import pubsub_v1
from google.oauth2 import service_account
from google.auth import load_credentials_from_file
from datetime import datetime
import boto3
import io
import gzip
import os
from botocore.exceptions import ClientError
import uuid
import time
from decimal import Decimal
from datetime import timedelta
from typing import List, Dict, Any

GCP_PROJECT_ID = os.environ.get("GOOGLE_CLOUD_PROJECT")
DYNAMODB_LOG_TABLE_NAME = os.environ.get("dynamo_log_table_name")
partition_key_name = os.environ.get("dynamo_partition_key")
sort_key_name = os.environ.get("dynamo_sort_key")
region_name= os.environ.get("region")
auth_method=os.environ.get("auth_method")
credential_file_path=os.environ.get("GOOGLE_APPLICATION_CREDENTIALS")
SNS_TOPIC_ARN = os.environ.get("sns_topic_arn")
PUBSUB_SUBSCRIPTION_LIST = os.environ.get("pubsub_subscription_list", "")
Environment=os.environ.get("Environment")
num_of_message_to_process = int(os.environ.get("num_of_pubsub_message_to_process"))
pubsub_read_message_timeout = int(os.environ.get("pubsub_read_message_timeout_seconds"))

cw_log_group = os.environ.get("AWS_LAMBDA_LOG_GROUP_NAME")
cw_log_stream = os.environ.get("AWS_LAMBDA_LOG_STREAM_NAME")

Lambda_run_time_utc = str(datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S'))
SNS_EMAIL_SUBJECT = f"CDC Processing Failed | {Environment} | {region_name}"

# Global dictionary to store table metadata (column names and their types)
# This will be populated only when a duplicate key error occurs for a table.
TABLE_METADATA_CACHE: Dict[str, Dict[str, str]] = {}

# --- NEW LSN SORTING FUNCTIONS ---
def lsn_to_int(lsn_str):
    """
    Converts a PostgreSQL LSN string (e.g., 'A/8D6C6FF8') to an integer for comparison.
    """
    if not isinstance(lsn_str, str) or '/' not in lsn_str:
        raise ValueError(f"Invalid LSN format: {lsn_str}. Expected 'X/Y'.")

    parts = lsn_str.split('/')
    if len(parts) != 2:
        raise ValueError(f"Invalid LSN format: {lsn_str}. Expected 'X/Y'.")

    try:
        file_id = int(parts[0], 16) << 32
        offset = int(parts[1], 16)
        return file_id | offset
    except ValueError as e:
        raise ValueError(f"Could not parse LSN parts '{lsn_str}': {e}")

def sort_events_by_lsn(events):
    """
    Sorts a list of event dictionaries by their LSN.
    Events without 'source_metadata' or 'lsn' will be placed at the end.
    """
    sortable_events = []
    for i, event in enumerate(events):
        try:
            lsn_str = event['source_metadata']['lsn']
            lsn_val = lsn_to_int(lsn_str)
            sortable_events.append((lsn_val, i, event))
        except (KeyError, ValueError) as e:
            print(f"Warning: Event missing valid LSN or source_metadata. Placing at end of sort. UUID: {event.get('uuid', 'N/A')}, Error: {e}")
            sortable_events.append((float('inf'), i, event))

    sortable_events.sort()
    sorted_events = [event for lsn_val, original_index, event in sortable_events]
    return sorted_events


def get_gcp_client(auth_method, gcpclient, credential_file_path, PUBSUB_SUBSCRIPTION_NAME):
    """
    Returns a GCS or Pub/Sub client using either Service Account or WIF authentication.
    """
    if auth_method == 'ServiceAccount':
        credentials = service_account.Credentials.from_service_account_file(credential_file_path)
    elif auth_method == 'WIF':
        credentials, project_id = load_credentials_from_file(credential_file_path)
    else:
        raise ValueError("Invalid auth_method. Use 'ServiceAccount' or 'WIF'.")

    if gcpclient == 'GCS':
        return storage.Client(credentials=credentials, project=GCP_PROJECT_ID)
    elif gcpclient == 'PubSub':
        subscriber = pubsub_v1.SubscriberClient(credentials=credentials)
        subscription_path = subscriber.subscription_path(GCP_PROJECT_ID, PUBSUB_SUBSCRIPTION_NAME)
        return subscriber, subscription_path
    else:
        raise ValueError("Invalid gcpclient. Use 'GCS' or 'PubSub'.")


def format_value(value):
    """
    Helper function to format values for SQL queries, handling different types.
    """
    if isinstance(value, str):
        return f"""'{value.replace("'", "''")}'"""
    elif isinstance(value, (int, float, Decimal)):
        return str(value)
    elif isinstance(value, dict):
        return f"""'{(json.dumps(value)).replace("None","null").replace("'","''")}'"""
    elif isinstance(value, list):
        return f"""ARRAY[{', '.join(format_value(item) for item in value)}]"""
    elif value is None:
        return 'NULL'
    else:
        return f"""'{str(value).replace("'", "''")}'"""

def format_value_based_on_type(value: Any, pg_type: str) -> str:
    """
    Formats a value for SQL based on its PostgreSQL data type.
    """
    string_types = ['text', 'varchar', 'char', 'uuid', 'json', 'jsonb', 'date', 'time', 'timestamp', 'timestamptz']
    numeric_types = ['smallint', 'integer', 'bigint', 'decimal', 'numeric', 'real', 'double precision']
    boolean_types = ['boolean']

    if pg_type in string_types:
        if value is None:
            return 'NULL'
        return f"""'{str(value).replace("'", "''")}'"""
    elif pg_type in numeric_types:
        if value is None:
            return 'NULL'
        try:
            return str(value)
        except ValueError:
            print(f"Warning: Value '{value}' for numeric type '{pg_type}' could not be converted to number. Quoting as string.")
            return f"""'{str(value).replace("'", "''")}'"""
    elif pg_type in boolean_types:
        if value is None:
            return 'NULL'
        return 'TRUE' if str(value).lower() == 'true' else 'FALSE'
    elif pg_type.startswith('_'): # Array types, e.g., _text, _int4
        if value is None:
            return 'NULL'
        if isinstance(value, list):
            element_pg_type = pg_type[1:]
            return f"""ARRAY[{', '.join(format_value_based_on_type(item, element_pg_type) for item in value)}]"""
        else:
            print(f"Warning: Value '{value}' for array type '{pg_type}' is not a list. Quoting as string.")
            return f"""'{str(value).replace("'", "''")}'"""
    else:
        if value is None:
            return 'NULL'
        return f"""'{str(value).replace("'", "''")}'"""


def publish_sns_notification(sns_topic_arn, subject, message, region):
    """
    Publishes a message to an SNS topic.
    """
    if not sns_topic_arn:
        print("SNS_TOPIC_ARN is not configured. Skipping SNS notification.")
        return

    sns_client = boto3.client('sns', region_name=region)
    try:
        response = sns_client.publish(
            TopicArn=sns_topic_arn,
            Subject=subject,
            Message=message
        )
        print(f"SNS notification published. MessageId: {response['MessageId']}")
    except ClientError as e:
        print(f"Error publishing SNS notification: {e.response['Error']['Message']}")
    except Exception as e:
        print(f"An unexpected error occurred while publishing SNS notification: {e}")


def get_table_metadata(cursor, schema_name: str, table_name: str) -> Dict[str, str]:
    """
    Fetches column names and their PostgreSQL data types for a given table.
    Caches the result in TABLE_METADATA_CACHE.
    Returns a dictionary like {'column_name': 'pg_type'}.
    """
    full_table_name = f"{schema_name}.{table_name}"
    if full_table_name in TABLE_METADATA_CACHE:
        return TABLE_METADATA_CACHE[full_table_name]

    query = f"""
        SELECT column_name, data_type
        FROM information_schema.columns
        WHERE table_schema = %s AND table_name = %s;
    """
    try:
        cursor.execute(query, (schema_name, table_name))
        metadata = {row[0]: row[1] for row in cursor.fetchall()}
        TABLE_METADATA_CACHE[full_table_name] = metadata
        return metadata
    except psycopg2.Error as e:
        print(f"Error fetching metadata for {full_table_name}: {e}")
        return {}


def parse_duplicate_key_error(error_message: str, table_metadata: Dict[str, str]) -> Dict[str, Any] | None:
    """
    Parses a PostgreSQL duplicate key error message to extract constraint name,
    key columns, and key values. Uses table_metadata to correctly type values.
    """
    constraint_pattern = r'unique constraint "([^"]+)"'
    key_detail_pattern = r'Key \(([^)]+)\)=\(([^)]+)\) already exists'

    constraint_match = re.search(constraint_pattern, error_message)
    key_detail_match = re.search(key_detail_pattern, error_message)

    if constraint_match and key_detail_match:
        constraint_name = constraint_match.group(1)
        key_columns_str = key_detail_match.group(1)
        key_values_str = key_detail_match.group(2)

        key_columns = [col.strip() for col in key_columns_str.split(',')]
        key_values_raw = [val.strip() for val in key_values_str.split(',')]

        key_values = []
        for i, col_name in enumerate(key_columns):
            if i < len(key_values_raw):
                raw_val = key_values_raw[i]
                pg_type = table_metadata.get(col_name)

                if pg_type:
                    if pg_type in ['smallint', 'integer', 'bigint', 'decimal', 'numeric', 'real', 'double precision']:
                        try:
                            key_values.append(Decimal(raw_val))
                        except ValueError:
                            key_values.append(raw_val)
                    elif pg_type in ['boolean']:
                        key_values.append(raw_val.lower() == 'true')
                    elif raw_val.startswith("'") and raw_val.endswith("'"):
                        key_values.append(raw_val[1:-1])
                    else:
                        key_values.append(raw_val)
                else:
                    print(f"Warning: Type for column '{col_name}' not found in metadata. Inferring type for '{raw_val}'.")
                    try:
                        key_values.append(int(raw_val))
                    except ValueError:
                        if raw_val.startswith("'") and raw_val.endswith("'"):
                            key_values.append(raw_val[1:-1])
                        else:
                            key_values.append(raw_val)
            else:
                print(f"Warning: Mismatch between key columns and values in error message for column '{col_name}'.")
                return None

        return {
            'constraint': constraint_name,
            'key_columns': key_columns,
            'key_values': key_values
        }
    return None


def execute_query_and_commit(cursor, query, record_entry=None, is_retry=False):
    """
    Helper static method to execute a query and commit the transaction.
    Handles duplicate key errors by attempting a DELETE and then retrying the INSERT.
    Returns True on success, False on failure, and the error message if any.
    """
    try:
        cursor.execute(query)
        rows_affected = cursor.rowcount
        return True, None, rows_affected
    except psycopg2.Error as e:
        error_msg = str(e)
        print(f"ERROR executing query: {query[:100]}...\nDetails: {error_msg}")

        if "duplicate key value violates unique constraint" in error_msg and \
           record_entry and record_entry.get('cdc_operation') == 'INSERT' and not is_retry:
            print("Detected duplicate key error for INSERT. Attempting to resolve...")

            schema_name = record_entry.get('schema_name')
            table_name = record_entry.get('table_name')

            if not schema_name or not table_name:
                print(f"Could not determine schema or table from record_entry for duplicate key resolution. Skipping DELETE/RETRY.")
                return False, error_msg, 0

            current_table_metadata = get_table_metadata(cursor, schema_name, table_name)
            if not current_table_metadata:
                print(f"Failed to retrieve table metadata for {schema_name}.{table_name}. Cannot resolve duplicate key error accurately. Skipping DELETE/RETRY.")
                return False, error_msg, 0

            parsed_error = parse_duplicate_key_error(error_msg, current_table_metadata)

            if parsed_error:
                key_columns = parsed_error['key_columns']
                key_values = parsed_error['key_values']

                where_clauses = []
                for i, col in enumerate(key_columns):
                    if i < len(key_values):
                        pg_type = current_table_metadata.get(col)
                        if pg_type:
                            where_clauses.append(f"{col} = {format_value_based_on_type(key_values[i], pg_type)}")
                        else:
                            print(f"Warning: Type for column '{col}' not found in metadata for DELETE WHERE clause. Using generic format_value.")
                            where_clauses.append(f"{col} = {format_value(key_values[i])}")
                    else:
                        print(f"Warning: Mismatch between key columns and values in error message for column '{col}'.")
                        return False, error_msg, 0

                delete_query = f"DELETE FROM {schema_name}.{table_name} WHERE {' AND '.join(where_clauses)};"
                print(f"Attempting DELETE to resolve duplicate key: {delete_query}")

                delete_success, delete_error_msg, delete_rows_affected = execute_query_and_commit(cursor, delete_query)

                if delete_success:
                    print(f"Successfully deleted {delete_rows_affected} conflicting record(s). Retrying original INSERT.")
                    # Retry the original INSERT query
                    return execute_query_and_commit(cursor, query, record_entry, is_retry=True)
                else:
                    print(f"Failed to delete conflicting record: {delete_error_msg}")
                    return False, error_msg, 0
            else:
                print("Could not parse duplicate key error details. Skipping DELETE/RETRY.")
                return False, error_msg, 0
        else:
            return False, error_msg, 0
    except Exception as e:
        error_msg = f"An unexpected error occurred during query execution: {e}"
        print(error_msg)
        return False, str(e), 0


def check_filename_exists_as_partitionkey(dynamodb_table_name, file_path, region_name):
    """
    Checks if a file_path exists with a FILE_SUMMARY entry in the single log table.
    """
    dynamodb = boto3.resource('dynamodb', region_name=region_name)
    table = dynamodb.Table(dynamodb_table_name)
    try:
        response = table.get_item(
            Key={
                'file_path': file_path,
                'query_id': 'FILE_SUMMARY'
            }
        )
        if 'Item' in response:
            file_process_status = response['Item']['event_status']
            print(f"File Process Status from DynamoDB : {file_process_status}")
            print(f"File '{file_path}' already has a FILE_SUMMARY entry in DynamoDB table {dynamodb_table_name} with Status : {file_process_status}")
            return False,file_process_status
        else:
            print(f"File '{file_path}' does NOT have a FILE_SUMMARY entry in DynamoDB table {dynamodb_table_name}")
            return True,False
    except ClientError as e:
        print(f"Error checking DynamoDB: {e.response['Error']['Message']}")
        return True,False


def process_jsonl_from_gcs(GCS_BUCKET_NAME, GCS_FILE_NAME, PUBSUB_SUBSCRIPTION_NAME):
    all_events_from_file = []
    file_errors = []
    sns_message = {
            'file_path': '',
            'pubsub_subscription_name': PUBSUB_SUBSCRIPTION_NAME,
            'event_status': '',
            'file_processing_error': 'Error in JSONL File Parsing',
            'region_name': region_name,
            'notification_type': 'File Parsing Failed',
            'error_message': 'N/A'
    }
    try:
        gcs_client = get_gcp_client(auth_method, 'GCS', credential_file_path, PUBSUB_SUBSCRIPTION_NAME)
        bucket = gcs_client.bucket(GCS_BUCKET_NAME)

        total_records_in_file = {}
        for file_name in GCS_FILE_NAME:
            file_path = f"{GCS_BUCKET_NAME}/{file_name}"
            sns_message['file_path'] = file_path
            blob = bucket.blob(file_name)
            content = blob.download_as_text()
            content = content.replace("\u2028","")
            file_lines = content.splitlines()
            total_lines = len(file_lines)
            total_records_in_file[file_path] = total_lines
            print(f"Total Number of Lines in File {file_name} : {total_lines}")

            for line_number, line in enumerate(file_lines, 1):
                try:
                    event_data = json.loads(line.strip())
                    event_data['file_path'] = file_path
                    all_events_from_file.append(event_data)
                except json.JSONDecodeError as e:
                    error_msg = f"Line {line_number}: JSON decode error - {e}. Content: '{line.strip()}'"
                    print(f"  Error: {error_msg}")
                    file_errors.append(error_msg)
                    sns_message['event_status'] = 'FAILED'
                    sns_message['error_message'] = error_msg
                    publish_sns_notification(SNS_TOPIC_ARN, SNS_EMAIL_SUBJECT, json.dumps(sns_message, indent=2), region_name)
                except Exception as e:
                    error_msg = f"Line {line_number}: An unexpected error occurred during parsing - {e}. Content: '{line.strip()}'"
                    print(f"  Error: {error_msg}")
                    file_errors.append(error_msg)
                    sns_message['event_status'] = 'FAILED'
                    sns_message['error_message'] = error_msg
                    publish_sns_notification(SNS_TOPIC_ARN, SNS_EMAIL_SUBJECT, json.dumps(sns_message, indent=2), region_name)

        if all_events_from_file:
            print(f"Sorting {len(all_events_from_file)} events by LSN...")
            sorted_events = sort_events_by_lsn(all_events_from_file)
            print("Events sorted by LSN.")
        else:
            sorted_events = []
            print("No valid events parsed from file to sort.")

        records_to_log = []
        file_processing_success = True

        for event_data in sorted_events:
            sns_line_message = {
                'file_path': event_data['file_path'],
                'pubsub_subscription_name': PUBSUB_SUBSCRIPTION_NAME,
                'event_status': '',
                'source_payload': '',
                'file_processing_error': 'Error while processing a single line(query) from combined JSONL file',
                'region_name': region_name,
                'notification_type': 'File Parsing Failed',
                'error_message': 'N/A'
            }
            record_start_time = time.time()
            record_query_id = str(uuid.uuid4())

            stream_name = event_data.get("stream_name", PUBSUB_SUBSCRIPTION_NAME)

            record_log_entry = {
                'file_path': event_data['file_path'],
                'query_id': f'{record_query_id}',
                'query_received_timestamp': datetime.utcnow().isoformat(),
                'cdc_operation': None,
                'schema_name': None,
                'table_name': None,
                'where_clause_column_name': [],
                'source_payload': None,
                'target_cdc_query': None,
                'rows_affected_added': 0,
                'processing_time': Decimal('0.0'),
                'query_status': 'SKIPPED',
                'query_error_message': None,
                'event_status': 'SKIPPED',
                'stream_name': stream_name
            }

            source_metadata = event_data.get("source_metadata")
            payload = event_data.get("payload")

            record_log_entry['source_payload'] = json.dumps(payload)
            sns_line_message['source_payload'] = record_log_entry['source_payload']
            if source_metadata:
                record_log_entry['cdc_operation'] = source_metadata.get("change_type")
                record_log_entry['where_clause_column_name'] = source_metadata.get("primary_keys", [])
                record_log_entry['schema_name'] = source_metadata.get("schema")
                record_log_entry['table_name'] = source_metadata.get("table")

            if not source_metadata or not payload:
                error_msg = f"Event (UUID: {event_data.get('uuid', 'N/A')}): Missing 'source_metadata' or 'payload'."
                print(f"  Warning: {error_msg} Skipping.")
                file_errors.append(error_msg)
                file_processing_success = False
                record_log_entry['query_status'] = 'SKIPPED'
                record_log_entry['event_status'] = 'SKIPPED'
                record_log_entry['query_error_message'] = error_msg
                record_log_entry['processing_time'] = Decimal(str(time.time() - record_start_time))
                records_to_log.append(record_log_entry)
                continue

            database = record_log_entry['schema_name']
            table = record_log_entry['table_name']
            change_type = record_log_entry['cdc_operation']
            primary_keys = record_log_entry['where_clause_column_name']

            prepared_query = None

            try:
                if change_type == "INSERT":
                    columns = []
                    values = []
                    for col, val in payload.items():
                        if val is None or (isinstance(val, str) and val.upper() == "NULL"):
                            if col.upper() == (str('resolves')).upper():
                                columns.append(col)
                                values.append(format_value({}))
                            continue
                        columns.append(col)
                        values.append(format_value(val))
                    prepared_query = f"INSERT INTO {database}.{table} ({', '.join(f'{col}' for col in columns)}) VALUES ({', '.join(values)});"
                    record_log_entry['rows_affected_added'] = 1
                elif change_type == "UPDATE-INSERT" or change_type == "UPDATE":
                    if not primary_keys:
                        raise ValueError("Primary keys are required for UPDATE operations.")

                    set_clauses = []
                    where_clauses = []
                    for col, val in payload.items():
                        if val is None or (isinstance(val, str) and val.upper() == "NULL"):
                            if col.upper() == (str('resolves')).upper():
                                columns.append(col)
                                values.append(format_value({}))
                            continue
                        if col not in primary_keys:
                            set_clauses.append(f"{col} = {format_value(val)}")
                        else:
                            where_clauses.append(f"{col} = {format_value(val)}")

                    if not set_clauses:
                        record_log_entry['query_status'] = 'SKIPPED'
                        record_log_entry['event_status'] = 'SKIPPED'
                        record_log_entry['query_error_message'] = "No changes detected for UPDATE."
                        record_log_entry['processing_time'] = Decimal(str(time.time() - record_start_time))
                        records_to_log.append(record_log_entry)
                        continue
                    elif not where_clauses:
                        raise ValueError("Cannot perform UPDATE without primary key values in payload.")
                    else:
                        prepared_query = f"UPDATE {database}.{table} SET {', '.join(set_clauses)} WHERE {' AND '.join(where_clauses)};"
                elif change_type == "DELETE":
                    if not primary_keys:
                        raise ValueError("Primary keys are required for DELETE operations.")

                    where_clauses = []
                    for pk in primary_keys:
                        if pk in payload:
                            where_clauses.append(f"{pk} = {format_value(payload[pk])}")
                        else:
                            raise ValueError(f"Primary key '{pk}' not found in payload for DELETE.")

                    if where_clauses:
                        prepared_query = f"DELETE FROM {database}.{table} WHERE {' AND '.join(where_clauses)};"
                    else:
                        raise ValueError("No valid primary key values found for DELETE.")
                else:
                    raise ValueError(f"Unhandled change_type '{change_type}'.")

                if prepared_query:
                    record_log_entry['target_cdc_query'] = prepared_query
                    record_log_entry['query_status'] = 'PENDING'
                    record_log_entry['event_status'] = 'PENDING'
                    record_log_entry['processing_time'] = Decimal(str(time.time() - record_start_time))
                    records_to_log.append(record_log_entry)

            except ValueError as e:
                error_msg = f"Event (UUID: {event_data.get('uuid', 'N/A')}): Data validation error - {e}"
                print(f"  Warning: {error_msg} Skipping.")
                file_errors.append(error_msg)
                file_processing_success = False
                record_log_entry['query_status'] = 'SKIPPED'
                record_log_entry['event_status'] = 'SKIPPED'
                record_log_entry['query_error_message'] = error_msg
                record_log_entry['processing_time'] = Decimal(str(time.time() - record_start_time))
                records_to_log.append(record_log_entry)
                sns_line_message['event_status'] = 'FAILED'
                sns_line_message['error_message'] = error_msg
                publish_sns_notification(SNS_TOPIC_ARN, SNS_EMAIL_SUBJECT, json.dumps(sns_line_message, indent=2), region_name)
            except Exception as e:
                error_msg = f"Event (UUID: {event_data.get('uuid', 'N/A')}): An unexpected error occurred during query preparation - {e}"
                print(f"  Warning: {error_msg} Skipping.")
                file_errors.append(error_msg)
                file_processing_success = False
                record_log_entry['query_status'] = 'SKIPPED'
                record_log_entry['event_status'] = 'SKIPPED'
                record_log_entry['query_error_message'] = error_msg
                record_log_entry['processing_time'] = Decimal(str(time.time() - record_start_time))
                records_to_log.append(record_log_entry)
                sns_line_message['event_status'] = 'FAILED'
                sns_line_message['error_message'] = error_msg
                publish_sns_notification(SNS_TOPIC_ARN, SNS_EMAIL_SUBJECT, json.dumps(sns_line_message, indent=2), region_name)

    except Exception as e:
        error_msg = f"Error downloading or processing file from GCS: {e}"
        print(f"Error: {error_msg}")
        file_errors.append(error_msg)
        file_processing_success = False
        sns_message['event_status'] = 'FAILED'
        sns_message['error_message'] = error_msg
        publish_sns_notification(SNS_TOPIC_ARN, SNS_EMAIL_SUBJECT, json.dumps(sns_message, indent=2), region_name)

    return records_to_log, file_processing_success, file_errors, total_records_in_file


def read_n_pubsub_message(PUBSUB_SUBSCRIPTION_NAME, n, pubsub_read_message_timeout):
    """
    Pull one message from Pub/Sub subscription (if available).
    Returns a tuple (message_data, ack_id) or (None, None) if no message.
    """
    subscriber,subscription_path = get_gcp_client(auth_method, 'PubSub', credential_file_path, PUBSUB_SUBSCRIPTION_NAME)
    response = subscriber.pull(
        request={
            "subscription": subscription_path,
            "max_messages": n
        },
        timeout=pubsub_read_message_timeout
    )

    received = response.received_messages
    if not received:
        print("No messages available to pull.")
        return []

    result_list = []
    i=1
    for rm in received:
        msg = rm.message
        ack_id = rm.ack_id
        print(f"PubSub Message No {i}")
        try:
            obj_meta = json.loads(msg.data)
            print(obj_meta)
            pubsub_message_id = obj_meta["id"]
            GCS_BUCKET_NAME = obj_meta["bucket"]
            GCS_FILE_NAME = obj_meta["name"]
            EventSize = obj_meta["size"]
            time_str = obj_meta.get("timeCreated")

            file_path=f"{GCS_BUCKET_NAME}/{GCS_FILE_NAME}"
            table_name = GCS_FILE_NAME.split("/")[1]
            if table_name.upper() == ("kdconf_runner_logs").upper():
                print(f"Skipping runner_logs table for file: {file_path} now. Sending Back ACK to sub-foldor Events for Ack ID : {ack_id}")
                send_ack(ack_id, PUBSUB_SUBSCRIPTION_NAME)
                i = i + 1
                continue

            print(f"Size of the Event Data : {EventSize}")
            if EventSize == "0":
                print(f"Event does not have JSONL file in it, its subfolder Events. Sending Back ACK to sub-foldor Events for Ack ID : {ack_id}")
                send_ack(ack_id, PUBSUB_SUBSCRIPTION_NAME)
                i=i+1
                continue

            file_not_processed_flag, file_process_status = check_filename_exists_as_partitionkey(DYNAMODB_LOG_TABLE_NAME, file_path, region_name)
            if not file_not_processed_flag:
                if file_process_status == 'SUCCESS':
                    print(f"File {file_path} already processed with SUCCESS Status. Sending back ACK to PubSub.")
                    send_ack(ack_id, PUBSUB_SUBSCRIPTION_NAME)
                if file_process_status == 'FAILED':
                    print(f"File {file_path} already processed with FAILED Status. Sending ACK to PubSub")
                    send_ack(ack_id, PUBSUB_SUBSCRIPTION_NAME)
                i=i+1
                continue

        except (ValueError, KeyError):
            GCS_BUCKET_NAME = obj_meta = None
            time_str = None

        ts = datetime.fromisoformat(time_str.rstrip("Z") + "+00:00")
        i=i+1
        result_list.append({
            "pubsub_message_id": pubsub_message_id,
            "bucket_name": GCS_BUCKET_NAME,
            "gcs_file_name": GCS_FILE_NAME,
            "file_size": EventSize,
            "time_created": ts,
            "ack_id": ack_id
        })

    return result_list


def bundle_by_time_window(
    sorted_records: List[Dict],
    window_sec: float = 5.0
) -> List[List[Dict]]:
    """
    Bundles sorted input records into sublists such that within each sublist,
    all records fall within a sliding window of `window_sec` seconds.
    """
    if not sorted_records:
        return []
    window = timedelta(seconds=window_sec)
    batches = []
    current_batch = [sorted_records[0]]
    batch_start = sorted_records[0]["time_created"]

    for rec in sorted_records[1:]:
        ts = rec["time_created"]
        if ts - batch_start <= window:
            current_batch.append(rec)
        else:
            batches.append({
                "batch_id": str(uuid.uuid4()),
                "records": current_batch
            })
            current_batch = [rec]
            batch_start = ts

    batches.append({
            "batch_id": str(uuid.uuid4()),
            "records": current_batch
        })

    return batches


def parse_message(message_str):
    """
    Parses message string as JSON and prints content.
    Returns GCS Bucket, File Location and Status Flag.
    """
    try:
        parsed = json.loads(message_str)
        GCS_BUCKET_NAME = parsed["bucket"]
        GCS_FILE_NAME = parsed["name"]
        EventSize = parsed["size"]
        FileName = parsed["name"]

        print(f"Size of the Event Data : {EventSize}")
        if EventSize == "0":
            print(f"Event does not have JSONL file in it, its subfolder Events")
            is_jsonl_file_event=False
        else:
            is_jsonl_file_event=True
        return GCS_BUCKET_NAME, GCS_FILE_NAME, FileName, is_jsonl_file_event, True
    except Exception as e:
        print(f"Error Message : {e}")
        print(f"Message is not valid JSON. Raw message:\n{message_str}")
        return '','','',False,False


def send_ack(ack_id, PUBSUB_SUBSCRIPTION_NAME):
    """
    Send ack back to Pub/Sub for the received message.
    """
    if not ack_id:
        print("No ack_id provided, cannot acknowledge message.")
        return

    subscriber,subscription_path = get_gcp_client(auth_method, 'PubSub', credential_file_path, PUBSUB_SUBSCRIPTION_NAME)
    subscriber.acknowledge(
        request={
            "subscription": subscription_path,
            "ack_ids": [ack_id]
        }
    )
    print(f"Acknowledged message with ack_id: {ack_id}")


def batch_log_to_dynamodb(dynamodb_table_name, region, log_entries):
    """
    Logs multiple processing results to DynamoDB using batch_writer.
    """
    if not log_entries:
        return

    dynamodb = boto3.resource('dynamodb', region_name=region)
    table = dynamodb.Table(dynamodb_table_name)
    try:
        with table.batch_writer() as batch:
            for entry in log_entries:
                batch.put_item(Item=entry)
        print(f"Successfully batch logged {len(log_entries)} records to DynamoDB table {dynamodb_table_name}.")
    except ClientError as e:
        print(f"Error batch logging to DynamoDB: {e.response['Error']['Message']}")
    except Exception as e:
        print(f"An unexpected error occurred while batch logging to DynamoDB: {e}")


def process_batch_jsonl_files(batch, batch_id, conn, cursor, PUBSUB_SUBSCRIPTION_NAME):

    message_processed_successfully = False
    current_stream_name = PUBSUB_SUBSCRIPTION_NAME
    successful_queries_count_list = {}
    failed_queries_count_list = {}
    GCS_FILE_NAME_list = []
    file_level_summary_entry_list = []
    sns_notification_details_list = []
    failed_file_path_list = []
    for jsonlfile in batch:
        file_level_summary_entry = {
            'file_path': 'N/A',
            'pubsub_subscription_name': PUBSUB_SUBSCRIPTION_NAME,
            'process_batch_id': batch_id,
            'query_id': 'FILE_SUMMARY',
            'processing_start_timestamp': datetime.utcnow().isoformat(),
            'total_records_in_file': 0,
            'successful_queries_executed': 0,
            'failed_queries_count': 0,
            'skipped_queries_count': 0,
            'event_status': 'FAILED',
            'file_processing_error': None,
            'processing_end_timestamp': None,
            'stream_name': current_stream_name,
            'lambda_run_starttime_utc': Lambda_run_time_utc,
            'cw_log_group' : cw_log_group,
            'cw_log_stream' : cw_log_stream
        }

        sns_notification_details = {
            'process_batch_id': batch_id,
            'region_name': region_name,
            'pubsub_subscription_name': PUBSUB_SUBSCRIPTION_NAME,
            'file_path': 'N/A',
            'notification_type': 'N/A',
            'error_message': 'N/A',
            'query_details': {}
        }

        GCS_BUCKET_NAME = jsonlfile['bucket_name']
        GCS_FILE_NAME = jsonlfile['gcs_file_name']
        FileName = jsonlfile['gcs_file_name']
        is_jsonl_file_event = True
        parse_flag = True
        file_level_summary_entry['file_path'] = f"{GCS_BUCKET_NAME}/{FileName}"
        sns_notification_details['file_path'] = f"{GCS_BUCKET_NAME}/{FileName}"

        successful_queries_count_list[f"{GCS_BUCKET_NAME}/{FileName}"] = 0
        failed_queries_count_list[f"{GCS_BUCKET_NAME}/{FileName}"] = 0

        GCS_FILE_NAME_list.append(GCS_FILE_NAME)
        file_level_summary_entry_list.append(file_level_summary_entry)
        sns_notification_details_list.append(sns_notification_details)

    records_to_log, file_parsing_success, file_errors, total_records_in_file = process_jsonl_from_gcs(GCS_BUCKET_NAME, GCS_FILE_NAME_list, PUBSUB_SUBSCRIPTION_NAME)

    if not file_parsing_success:
        for file_level_summary_entry,sns_notification_details in zip(file_level_summary_entry_list, sns_notification_details_list):
            error_detail = f"File parsing or query generation failed. Errors: {'; '.join(file_errors)}"
            file_level_summary_entry['event_status'] = 'FAILED'
            file_level_summary_entry['file_processing_error'] = error_detail
            print(f"File parsing or query generation failed for {file_level_summary_entry['file_path']}. Errors: {file_errors}")
            file_level_summary_entry['processing_end_timestamp'] = datetime.utcnow().isoformat()

            sns_notification_details['notification_type'] = 'File Parsing Failed'
            sns_notification_details['error_message'] = error_detail
            publish_sns_notification(SNS_TOPIC_ARN, SNS_EMAIL_SUBJECT, json.dumps(sns_notification_details, indent=2), region_name)

        all_items_to_log = records_to_log + file_level_summary_entry_list
        batch_log_to_dynamodb(DYNAMODB_LOG_TABLE_NAME, region_name, all_items_to_log)
        return

    for file_level_summary_entry,sns_notification_details in zip(file_level_summary_entry_list, sns_notification_details_list):
        file_level_summary_entry['total_records_in_file'] = total_records_in_file[file_level_summary_entry['file_path']]
        file_level_summary_entry['stream_name'] = PUBSUB_SUBSCRIPTION_NAME
        sns_notification_details['pubsub_subscription_name'] = PUBSUB_SUBSCRIPTION_NAME

    for records in records_to_log:
        records['process_batch_id'] = batch_id
        records['pubsub_subscription_name'] = PUBSUB_SUBSCRIPTION_NAME
        records['lambda_run_starttime_utc'] = Lambda_run_time_utc


    transaction_successful = True
    successful_queries_count = 0
    failed_queries_count = 0
    skipped_queries_count = 0


    queries_to_execute = [rec for rec in records_to_log if rec.get('target_cdc_query') is not None]

    try:
        conn.autocommit = True
        for record_entry in queries_to_execute:
            query_execution_start_time = time.time()
            query = record_entry['target_cdc_query']
            query_file_path = record_entry['file_path']
            success, error_msg, rows_affected = execute_query_and_commit(cursor, query, record_entry)

            record_entry['processing_time'] = record_entry['processing_time'] + Decimal(str(time.time() - query_execution_start_time))

            if success:
                record_entry['query_status'] = 'SUCCESS'
                record_entry['event_status'] = 'SUCCESS'
                record_entry['rows_affected_added'] = rows_affected
                successful_queries_count += 1
                successful_queries_count_list[query_file_path] += 1
            else:
                failed_file_path_list.append(query_file_path)
                failed_queries_count += 1
                failed_queries_count_list[query_file_path] += 1
                failed_file_path = query_file_path
                record_entry['query_error_message'] = error_msg
                transaction_successful = False
                print(f"Query FAILED, so skipping this Query and Proceeding with Other Queries")
                record_entry['query_status'] = 'FAILED'
                record_entry['event_status'] = 'FAILED'
                for sns in sns_notification_details_list:
                    if sns['file_path'] == failed_file_path:
                        sns['query_details'] = {
                            'query': query,
                            'schema_name': record_entry.get('schema_name', 'N/A'),
                            'table_name': record_entry.get('table_name', 'N/A'),
                            'cdc_operation': record_entry.get('cdc_operation', 'N/A')
                            }
                        sns['error_message'] = error_msg + " Transaction NOT Rolled Back."
                        sns['query_status'] = 'FAILED'
                        publish_sns_notification(SNS_TOPIC_ARN, SNS_EMAIL_SUBJECT, json.dumps(sns, indent=2), region_name)

        unique_failed_file_path_list = list(set(failed_file_path_list))
        for file_level_summary_entry in file_level_summary_entry_list:
            skipped_queries_count = len(records_to_log) - len(queries_to_execute)
            if len(successful_queries_count_list) != 0:
                file_level_summary_entry['successful_queries_executed'] = successful_queries_count_list[file_level_summary_entry['file_path']]
            else:
                file_level_summary_entry['successful_queries_executed'] = 0

            if len(failed_queries_count_list) != 0:
                file_level_summary_entry['failed_queries_count'] = failed_queries_count_list[file_level_summary_entry['file_path']]
            else:
                file_level_summary_entry['failed_queries_count'] = 0

            file_level_summary_entry['skipped_queries_count'] = skipped_queries_count

        if transaction_successful:
            for file_level_summary_entry in file_level_summary_entry_list:
                if file_level_summary_entry['successful_queries_executed'] == file_level_summary_entry['total_records_in_file']:
                    print(f"Successfully executed all {file_level_summary_entry['successful_queries_executed']} queries for {file_level_summary_entry['file_path']}.")
                    file_level_summary_entry['event_status'] = 'SUCCESS'
                else:
                    print(f"Successfully executed some {file_level_summary_entry['successful_queries_executed']} queries out of {file_level_summary_entry['total_records_in_file']} Queries for {file_level_summary_entry['file_path']}.")
                    file_level_summary_entry['event_status'] = 'FAILED'
                file_level_summary_entry['processing_end_timestamp'] = datetime.utcnow().isoformat()
            print(f"Successfully Total {successful_queries_count} queries for batch : {batch_id} from total {len(batch)} Files")
            message_processed_successfully = True
        else:
            for file_level_summary_entry in file_level_summary_entry_list:
                if file_level_summary_entry['file_path'] in unique_failed_file_path_list:
                    print(f"Error: Some of the queries failed for file {failed_file_path}")
                    error_detail = f'Some of the queries failed for file {failed_file_path}'
                    file_level_summary_entry['event_status'] = 'FAILED'
                    file_level_summary_entry['file_processing_error'] = error_detail
                else:
                    print(f"Successfully executed all queries for file {file_level_summary_entry['file_path']}")
                    file_level_summary_entry['event_status'] = 'SUCCESS'
                file_level_summary_entry['processing_end_timestamp'] = datetime.utcnow().isoformat()

    except Exception as e:
        error_detail = f"An unexpected error occurred during transaction: {e}"
        file_level_summary_entry['event_status'] = 'FAILED'
        file_level_summary_entry['file_processing_error'] = error_detail
        file_level_summary_entry['processing_end_timestamp'] = datetime.utcnow().isoformat()
        print(f"An unexpected error occurred during transaction for {file_level_summary_entry['file_path']}: {e}")

        sns_notification_details['notification_type'] = f"Query Execution Failed (Unexpected)"
        sns_notification_details['error_message'] = error_detail
        publish_sns_notification(SNS_TOPIC_ARN, SNS_EMAIL_SUBJECT, json.dumps(sns_notification_details, indent=2), region_name)

    all_items_to_log = records_to_log + file_level_summary_entry_list
    batch_log_to_dynamodb(DYNAMODB_LOG_TABLE_NAME, region_name, all_items_to_log)

    for jsonlfile in batch:
        if f"{jsonlfile['bucket_name']}/{jsonlfile['gcs_file_name']}" in unique_failed_file_path_list:
            print(f"Error: Sending back ACK to PubSub after logging into Dynamo for File {jsonlfile['bucket_name']}/{jsonlfile['gcs_file_name']} having Ack Id : {jsonlfile['ack_id']}")
        else:
            print(f"Sending back ACK to PubSub for File {jsonlfile['bucket_name']}/{jsonlfile['gcs_file_name']} having Ack Id : {jsonlfile['ack_id']}")
        send_ack(jsonlfile['ack_id'], PUBSUB_SUBSCRIPTION_NAME)


def lambda_handler(event, context):
    print(f"LAMBDA Run Time : {Lambda_run_time_utc}")
    PARSED_PUBSUB_SUBSCRIPTION_LIST = [item for item in PUBSUB_SUBSCRIPTION_LIST.split(",") if item]
    print(f"PubSub Subscription List to Parse : {PARSED_PUBSUB_SUBSCRIPTION_LIST}")
    print("Cloudwatch Log Group:", cw_log_group)
    print("Cloudwatch Log Stream:", cw_log_stream)

    conn = None
    cursor = None
    try:
        conn = psycopg2.connect(
            host=os.environ.get("rds_host"),
            user=os.environ.get("rds_user"),
            password=os.environ.get("rds_password"),
            dbname=os.environ.get("rds_dbname")
        )
        conn.autocommit = True
        cursor = conn.cursor()
        cursor.execute("ANALYZE;")
        print("Connected to RDS and ran ANALYZE.")
        cursor.execute("SET session_replication_role = 'replica';")
        print("Session replication role set to replica")


        for PUBSUB_SUBSCRIPTION_NAME in PARSED_PUBSUB_SUBSCRIPTION_LIST:
            print(f"Processing {num_of_message_to_process} Messages for PubSub Subscription : {PUBSUB_SUBSCRIPTION_NAME}")
            sorted_result_list = read_n_pubsub_message(PUBSUB_SUBSCRIPTION_NAME, num_of_message_to_process, pubsub_read_message_timeout)
            batches = bundle_by_time_window(sorted_result_list, 10)
            print(f"\n📦 Pubsub Subs : {PUBSUB_SUBSCRIPTION_NAME} , Number of Batches : {len(batches)} , Number of Valid JSONL Files to Process : {len(sorted_result_list)}")
            i=1
            for batch in batches:
                batch_id = batch["batch_id"]
                print(f"\n📦 Processing Batch No: {i} having batch_id={batch_id}, {len(batch['records'])} Number of JSONL Files")
                process_batch_jsonl_files(batch["records"], batch_id, conn, cursor, PUBSUB_SUBSCRIPTION_NAME)
                i=i+1

        cursor.execute("SET session_replication_role = 'origin';")
        print("Session replication role set back to origin")
    except Exception as e:
        print(f"Error connecting to database or during main execution: {e}")
        email_message_body = f"LAMBDA Execution Failure Ocurred. Reasons can be 1. DB connection Failure 2. PubSub Data Pulling Failure 3. Batching Files Processing Failure. For Details please refer to the Cloudwtatch Log Group of the CDC Lambda at Timestamp : {Lambda_run_time_utc} "
        publish_sns_notification(SNS_TOPIC_ARN, SNS_EMAIL_SUBJECT, email_message_body, region_name)
        raise
    finally:
        if cursor:
            cursor.execute("SET session_replication_role = 'origin';")
            cursor.close()
        if conn:
            conn.close()
        print("Database connection closed.")
        